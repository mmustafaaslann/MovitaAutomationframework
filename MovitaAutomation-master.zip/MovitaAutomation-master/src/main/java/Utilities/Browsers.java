package Utilities;

public enum Browsers {
    CHROME,
    EDGE,
    SAFARI,
    FİREFOX
    ;
}
